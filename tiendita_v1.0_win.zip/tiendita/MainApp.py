import csv
from random import randint, uniform, choice

import kivy
from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import Logger  # Debugger
from kivy.properties import ObjectProperty, NumericProperty
from kivy.storage.dictstore import DictStore
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.textinput import TextInput

kivy.require('1.11.1')

Builder.load_file('store.kv')


class ButtonPopup(Popup):
    text = ObjectProperty('Default')

    def __init__(self, **kwargs):
        super(ButtonPopup, self).__init__(**kwargs)
        box = BoxLayout(orientation='vertical')
        box.add_widget(Label(text=self.text))
        close = Button(text='Cerrar',
                       size_hint_y=None)
        close.bind(on_press=self.dismiss)
        box.add_widget(close)
        self.add_widget(box)


class Item(RelativeLayout):
    global pricelist
    img_source = ObjectProperty(None)
    itm_name = ObjectProperty(None)
    stock = NumericProperty(None)
    price = NumericProperty(None)

    def __init__(self, **kwargs):
        super(Item, self).__init__(**kwargs)
        self.stock = randint(1, 10)
        lowprice = uniform(10, 50)
        highprice = uniform(100, 300)
        if self.price is None:
            self.price = round(choice((lowprice, highprice)), 2)
        Clock.schedule_interval(lambda dt: self.check_stock(), 0.1)

    def add_to_cart(self):
        if self.stock > 0:
            in_cart = 1
            pricelist.put(self.itm_name,
                          price=self.price,
                          cart=in_cart,
                          stock=self.stock)
        else:
            ButtonPopup(text='Ya no puedes comprar este objeto').open()

    def check_stock(self):
        if not (self.stock == pricelist.get(self.itm_name)['stock']):
            self.stock = pricelist.get(self.itm_name)['stock']
            Logger.info('{}: changed stock'.format(self.itm_name))


class BuyItem(BoxLayout):
    name = ObjectProperty(None)
    price = ObjectProperty(None)
    global pricelist

    def __init__(self, **kwargs):
        super(BuyItem, self).__init__(**kwargs)
        self.add_widget(Label(text=self.name))
        self.add_widget(Label(text='${}'.format(self.price)))
        self.txt1 = TextInput(halign='right',
                              multiline=False,
                              input_filter='int',
                              text=str(1))
        self.txt1.bind(on_text_validate=self.update_total)
        self.add_widget(self.txt1)
        self.total = Label(text='${}'.format(self.price))
        self.add_widget(self.total)
        Clock.schedule_once(self.add_price, 0.1)

    def add_price(self, dt):
        self.parent.parent.parent.costs[self.name] = self.price

    def update_total(self, value):
        checkout = self.parent.parent.parent
        new_total = int(value.text) * float(self.price)
        stock = pricelist.get(self.name)['stock']
        if int(value.text) > stock:
            self.total.color = (1, 0, 0, 1)
            self.total.text = 'SIN STOCK SUFICIENTE'
            checkout.can_buy = False
        else:
            self.total.color = (1, 1, 1, 1)
            self.total.text = '${}'.format(new_total)
            checkout.costs[self.name] = new_total
            price = pricelist.get(self.name)['price']
            pricelist.put(self.name,
                          price=price,
                          cart=int(value.text),
                          stock=stock)
            checkout.can_buy = True


class WelcomeScreen(Screen):
    pass


class ShopScreen(Screen):
    global pricelist
    cart_count = NumericProperty(0)

    def __init__(self, **kwargs):
        super(ShopScreen, self).__init__(**kwargs)
        with open('items.csv', mode='r') as csv_file:
            csv_read = csv.DictReader(csv_file)
            for line in csv_read:
                itm = Item(itm_name=line['Nombre'],
                           img_source="items/{}".format(line['Imagen']))
                pricelist.put(itm.itm_name,
                              price=itm.price,
                              cart=0,
                              stock=itm.stock)
                self.ids.scrl.add_widget(itm)
            Clock.schedule_interval(lambda dt: self.update_count(), 0.1)

    def update_count(self):
        self.cart_count = 0
        for item in pricelist:
            self.cart_count += pricelist.get(item)['cart']


class CheckoutScreen(Screen):
    global pricelist
    items = []
    costs = {}
    can_buy = True

    def __init__(self, **kwargs):
        super(CheckoutScreen, self).__init__(**kwargs)
        Clock.schedule_interval(lambda dt: self.update_inv(), 1)

    def update_inv(self):
        for item in pricelist:
            if pricelist.get(item)['cart'] > 0:
                try:
                    self.items.index(item)
                except ValueError:
                    self.items.append(item)
                    self.add_label(item)
                    Logger.info('Checkout: {} added'.format(item))
                    Logger.info('Checkout: items {}'.format(self.items))

    def add_label(self, itm_name):
        itm = BuyItem(name=itm_name,
                      price=pricelist.get(itm_name)['price'])
        self.ids.itms.add_widget(itm)

    def clear(self):
        self.ids.itms.clear_widgets()
        self.items = []
        for item in pricelist:
            price = pricelist.get(item)['price']
            stock = pricelist.get(item)['stock']
            pricelist.put(item, price=price, stock=stock, cart=0)
        Logger.info('Checkout: Cart cleared')

    def purchase(self):
        if self.can_buy:
            ButtonPopup(text='Total: ${}\n'.format(sum(self.costs.values())) +
                             'Gracias por tu compra').open()
            Logger.info('Costs: {}'.format(sum(self.costs.values())))
            for item in self.items:
                price = pricelist.get(item)['price']
                stock = pricelist.get(item)['stock']
                cart = pricelist.get(item)['cart']
                stock -= cart
                pricelist.put(item,
                              price=price,
                              cart=0,
                              stock=stock)
                Logger.info('Purchase: {} {}'.format(item, pricelist.get(item)))
            self.clear()
        else:
            ButtonPopup(text='No').open()


class StoreApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(WelcomeScreen(name='Welcome'))
        sm.add_widget(ShopScreen(name='Shop'))
        sm.add_widget(CheckoutScreen(name='Checkout'))
        return sm


if __name__ == '__main__':
    pricelist = DictStore(None)
    StoreApp().run()
